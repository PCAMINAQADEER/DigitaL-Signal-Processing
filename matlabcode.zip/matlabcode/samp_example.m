close all
clear all
clf
% read a wave file, put your own wave file here
[x,fs]=audioread('Bach2.wav');

sound(x,fs)
% the continuous signal 
pause

figure(1)
subplot(311), plot(x(1000:1100), 'r'); 
hold on
pause
plot(x(1000:1100), 'o'); grid;
title('sampling rate is Fs = 11.025 KHz')
pause
hold off

figure(2)
subplot(311), plot(abs(fftshift(fft(x))));grid;
title('sampling rate is Fs = 11.025 KHz');




% half of the original sampling rate
x1=x(1:2:length(x));
sound(x1,fs/2)
pause

figure(1)
subplot(312), plot(x(1000:2:1100), 'r'); hold on
pause
plot(x(1000:2:1100), 'o');grid;
title('sampling rate is Fs = 5.125 KHz')

pause
hold off
figure(2)
subplot(312), plot(abs(fftshift(fft(x1))));grid;
title('sampling rate is Fs = 5.125 KHz')



% 1/4 of the original sampling rate
x2=x(1:4:length(x));
sound(x2,fs/4)
pause
figure(1)
subplot(313), plot(x(1000:4:1100), 'r'); hold on
pause
plot(x(1000:4:1100), 'o');grid;
title('sampling rate is Fs = 2.756 KHz')

pause
hold off
figure(2)
subplot(313), plot(abs(fftshift(fft(x2))));grid;
title('sampling rate is Fs = 2.756 KHz')

