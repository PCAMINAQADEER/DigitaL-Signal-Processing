% Demo for showing the interpolation/ UpSampling
% We will upsample the signal
% Plot the signal in time domain
% See the effect  of upsampling in frequency domain
% filter out the desired signal and see the reconstruction
% By Dr Ali Hassan
% DAted : 26 May 2021
clear all
close all
%% Reading the audio
[x, fs] = audioread('wavefile.wav');

x = mean(x,2); % Stereo to Mono sound
%sound(x, fs);

%% Upsampling by 5
L = 5;
y = zeros(1, L*length(x));
y(1:L:end) = x;

%% plotting the signal in time domain
figure, stem(x(450:500)), xlabel('Samples'), title('Original signal')
figure, stem(y(L*450:L*450+250)), xlabel('Samples'), title('Upsampled signal with added zeros')
pause;

%% Plotting the frequency response of the original and upsampled signal
figure, plot(fftshift(abs(fft(x)))), title('Frequency respnose of Original Signal')
figure, plot(fftshift(abs(fft(y)))), title('Frequency respnose of Upsampled Signal')
pause;
%% Designing the filter
h = fir1(200,1/L); % 200 coefficients with cut off pi/L
figure, stem(h), title('Reconstruction Filter')
figure, plot(fftshift(abs(fft(h)))), title('Frequency response of Reconstruction filter')
pause;
%% Filtering the signal

out = filter(h, 1, y);
figure, plot(fftshift(abs(fft(out)))), title('Frequency response of the filtered signal')
figure, stem(out(L*450:L*450+250)), title('Zoomed version of the reconstructed filter')