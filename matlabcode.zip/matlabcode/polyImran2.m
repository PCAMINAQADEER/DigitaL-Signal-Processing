%Interpolation using polyphase decomposition
clear all;
close all;

x=[1     2    -1     2     3     4     5    -1     2     3     4     2];
fN = 1024;

[x,fs] = audioread('wavefile.wav');
x = x(5000:fs*7-1)';
fN = 64000;


L = 4;
U = 2;%interpolation by 2
wc = 1/U;

h = fir1(L-1, wc);

p0 = h(1:2:L);
p1 = h(2:2:L);

figure(1);
subplot(311), stem(h), ylabel('h');
subplot(312), stem(p0), ylabel('p0');
subplot(313), stem(p1), ylabel('p1');

N = length(x);
y = zeros(1, 2*N-1);
y(1:2:end) = x;

figure(2);
X=fft(x, fN);
Y=fft(y, fN);

plot(abs(X));
hold on;
plot(abs(Y), 'r');
hold off;
legend('Original sequence','Before interpolation(Only Zeros inserted)');

yi = conv(h, y);

figure(3);
plot(abs(Y));
hold on;
plot(abs(fft(yi,fN)), 'r');
hold off;
legend('Before interpolation(Only Zeros inserted)','After Interpolation with filter');

figure(4);
y0 = conv(x, p0);
y1 = conv(x, p1);
yp = zeros(1,2*N+2);
yp(1:2:end) = y0;
yp(2:2:end) = y1;
subplot(211), stem(yi), ylabel('yi');
subplot(212), stem(yp), ylabel('yp');

figure(5);
plot(abs(fft(yi,fN)));
hold on;
plot(abs(fft(yp,fN)), 'r');
hold off;
legend('Interpolation without polyphase decomposition','Interpolation with polyphase decomposition');
title('Completely Same');



