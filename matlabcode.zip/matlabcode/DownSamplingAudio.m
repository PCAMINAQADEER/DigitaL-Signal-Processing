% Demo for showing the Decimation/Downsampling of an audio signal
% We will downsample the signal
% Plot the signal in time domain
% See the effect  of downsampling in frequency domain
% 
% By Dr Ali Hassan
% DAted : 26 May 2021
clear all
close all

%% Reading the audio
[x, fs] = audioread('wavefile.wav');
x = mean(x,2); % Stereo to Mono sound
sound(x, fs);

%% Plotting the spectrum of the signal
N = length(x);
figure,
subplot(2,1,1), plot(x), hold on, xlabel('Time domain speech signal')
subplot(2,1,2), plot(abs(fft(x, N))), xlabel('FFT Spectrum of the signal'), ylabel('X(e(jw))');

%% Downsampling the signal by M=2
M = 2;
x2 = x(1:M:end);
figure, 
subplot(2,1,1), plot(x2), hold on, xlabel('Downsampled Signal by M = 2')
subplot(2,1,2), plot(abs(fft(x2, N))), xlabel('FFT Spectrum of the signal'), ylabel('X(e(jw))');

%% Downsampling the signal by M=4
M = 4;
x4 = x(1:M:end);
figure, 
subplot(2,1,1), plot(x4), hold on, xlabel('Downsampled Signal by M = 4')
subplot(2,1,2), plot(abs(fft(x4, N))), xlabel('FFT Spectrum of the signal'), ylabel('X(e(jw))');

%% Playing the audio
input('press enter to listen original voice');
player = audioplayer(x,fs);
playblocking(player)

input('press enter to listen Decimated voice by 2');
player = audioplayer(x2,fs/2);
playblocking(player)

input('press enter to listen Decimated voice by 4');
player = audioplayer(x4,fs/4);
playblocking(player)
