close all
clear all

%% UnComment this if
% Input from the Mic, if it is working
% Fs = 8000;
% input('press enter and start recording');
% x_fix = wavrecord(5*Fs, Fs, 'int16');
% input('voice has been recorded, press enter to listen');
% wavplay(x_fix, Fs);
% x = double(x_fix);
% N = length(x);

%% Reading from a file directly
[x_fix,Fs] = audioread('Bach2.wav');
% Play the sound file
input('voice has been read, press enter to listen');
% sound(x_fix, Fs)
player = audioplayer(x_fix,Fs);
playblocking(player)
% converting the stereo sound to mono
x = mean(x_fix,2);
N = length(x);

%%

subplot(411), plot(x), ylabel('x[n]');
[X, w] = freqz(x, 1, N, 'whole');
subplot (412), plot((w/(2*pi))*Fs, abs(X), 'r'), ylabel('X(e(jw))');

M1 = 2;
x_deci2 = x(1:M1:N);

[Xd2, w2] = freqz(x_deci2, 1, N/M1, 'whole');
subplot (413), plot(w2/(2*pi)*Fs/M1, abs(Xd2), 'r'), ylabel('Xd(e(jw))');
xlabel('freq in Hz');

%%

M2 = 4;
x_deci4 = x(1:M2:N);

[Xd4, w4] = freqz(x_deci4, 1, N/M2, 'whole');
subplot (414), plot(w4/(2*pi)*Fs/M2, abs(Xd4), 'r'), ylabel('Xd(e(jw))');
xlabel('freq in Hz')

input('press enter to listen decimated voice by a factor of 2');
player = audioplayer(x_deci2,Fs);
playblocking(player)


% y_in2 = interp(x_deci2, M1);
% for i=1:2
% % 	wavplay(int16(y_in2), Fs);
%     player = audioplayer(int16(y_in2),Fs);
%     playblocking(player)
%    pause
% end

input('press enter to listen further decimated voice by a factor of 4');
player = audioplayer(x_deci4,Fs);
playblocking(player)

% 
% y_in4 = interp(x_deci4, M2);
% pause;
% for i=1:2
%    wavplay(int16(y_in4), Fs);
%    pause
% end

figure (2)
Xabs = abs(X);
Xmax = max(Xabs);
plot(Xabs);
hold on
Xd2abs = abs(Xd2);
Xd2max = max(Xd2abs);
plot(Xd2abs + Xmax, 'g.')
plot(abs(Xd4) + Xd2max + Xmax, 'r.');

