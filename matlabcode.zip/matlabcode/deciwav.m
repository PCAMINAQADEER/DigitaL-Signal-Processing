close all
clear all

%%
[x_fix,Fs] = audioread('wavefile.wav');
[x_fix, Fs] = audioread('Bach2.wav');
x_fix = x_fix(:,1);

%wavplay(x_fix, Fs);
player = audioplayer(x_fix,Fs);
playblocking(player)

x = double(x_fix);
N = 12004;

subplot(411), plot(x), ylabel('x[n]');
[X, w] = freqz(x, 1, N, 'whole');
subplot (412), plot((w/(2*pi))*Fs, abs(X), 'r'), ylabel('X(e(jw))');

M1 = 2;
x_deci2 = x(1:M1:end);

[Xd2, w2] = freqz(x_deci2, 1, N/M1, 'whole');
subplot (413), plot(w2/(2*pi)*Fs/M1, abs(Xd2), 'r'), ylabel('Xd(e(jw))');
xlabel('freq in Hz');



M2 = 4;
x_deci4 = x(1:M2:end);

[Xd4, w4] = freqz(x_deci4, 1, N/M2, 'whole');
subplot (414), plot(w4/(2*pi)*Fs/M2, abs(Xd4), 'r'), ylabel('Xd(e(jw))');
xlabel('freq in Hz')

%%
input('press enter to listen decimated voice');
y_in2 = interp(x_deci2, M1);

player = audioplayer(x_deci2,Fs/2);
playblocking(player)

% for i=1:2
% 	sound(y_in2, Fs);
%    pause
% end

input('press enter to listen further decimated voice');
y_in4 = interp(x_deci4, M2);

player = audioplayer(x_deci4,Fs/4);
playblocking(player)

% for i=1:2
%    sound(y_in4, Fs);
%    pause
% end

figure (2)
Xabs = abs(X);
Xmax = max(Xabs);
plot(Xabs);
hold on
Xd2abs = abs(Xd2);
Xd2max = max(Xd2abs);
plot(Xd2abs + Xmax, 'g.')
plot(abs(Xd4) + Xd2max + Xmax, 'r.');

