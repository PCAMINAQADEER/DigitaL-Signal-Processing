% Demo for showing the effect of group delay on signals while using FIR and
% IIR filters.
% You will have to use the FDA tool box for desiging the filters.
% 
% By Dr Ali Hassan
% Dated : 02 Jun 2021

%%
close all
clear all


t = 0:1/1e3:2;
x = chirp(t, 0 , 1, 250);
plot(t,x), grid on, box on
figure, plot(abs(fft(x))), grid on, box on

%% Start Filter Designer tool box for desiging FIR 
% export the coefficients 
% This will export the coefficents in the variable Num
filterDesigner

%%
% Design & Export  the coefficients using FDA Tool FIR Filter
figure, plot(filter(Num, 1, x)), grid on, box on

%% Start Filter Designer tool box for desiging IIR 
% export the coefficients 
% This will export the coefficents in the variable G
filterDesigner

%%
% Design & Export  the coefficients using FDA Tool IIR Filter
figure, plot(filter(G, 1, x)), grid on, box on
