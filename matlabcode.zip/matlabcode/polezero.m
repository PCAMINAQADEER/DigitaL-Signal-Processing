N=1024;
a=[1 -0.8741 0.9217 -0.2672]; 
b=[0.1866 0.2036 0.2036 0.1866]; 
[z, p, k] = tf2zp(b, a); 
figure(1)
zplane(z, p)
pause
figure(2)
[H, w] = freqz(b, a, N,'whole');
subplot(211), plot(w/(2*pi),abs(H)), ylabel('H(e(jw))'); 
subplot(212), plot(w/(2*pi), angle(H)), ylabel('Phase of H(e(jw)');
