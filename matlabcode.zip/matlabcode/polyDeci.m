%Decimation using polyphase decomposition
clear all;

[x,fs] = audioread('wavefile.wav');

x = x(:,1);

L = 2; 
len  = 40;   
wc = 1/L; %cut-off frequency is pi/2.

h = fir1(len-1, wc);

p0 = h(1:2:len);
p1 = h(2:2:len);

figure(1);
subplot(311), stem(h), ylabel('h'), title('Complete fitler');
subplot(312), stem(p0), ylabel('p0'), title('Polyphase Filter 1');
subplot(313), stem(p1), ylabel('p1'), title('Polyphase fitler 2');
pause

y = conv(h, x);
N = length(y);
yd = y(2:2:N);

figure(2);
[X, wx] = freqz(x, 1, N, 'whole');
[Y, wy] = freqz(y, 1, N, 'whole');
[H, wh] = freqz(h, 1, 1024, 'whole');

subplot(311), plot(wx/(2*pi), abs(X)), title('Fourier Transform of x[n]');
subplot(312), plot (wh/(2*pi), abs(H)), title('Fourier Transform of filter h[n]');
subplot(313), plot(wy/(2*pi), abs(Y), 'r'), title('Fourier Transform of output y[n]');

legend('Original Sequence','Seq. after filtering');
pause

figure(3);
len_x = length(x);
x0 = x(2:2:len_x);
x1 = x(1:2:len_x);
subplot(311), plot(x), ylabel('x'), title('Original input signal x[n]')
subplot(312), plot(x0), ylabel('x0'), title('Origitnal input signal x0[n]')
subplot(313), plot(x1), ylabel('x1'), title('Origitnal input signal x1[n]')
pause

figure (4);
y0 = conv(x0, p0);
y1 = conv(x1, p1);
N1 = length(y0);
N2 = length (y1);
N = min(N1, N2);
yp = y0(1:N) + y1(1:N);

subplot(211), plot(yd), ylabel('yd'), title('Original output signal y[n] without Polyphase Filtering');
subplot(212), plot(yp), ylabel('yp'), title('Output signal y[n] after Polyphase Fitlering');
pause

figure(5);
Yd=fft(yd);
Yp=fft(yp);
subplot(211), plot(abs(Yd));
subplot(212), plot(abs(Yp), 'r');

legend('Decimation without polyphase decomposition','Decimation with polyphase decomposition');
title('Completely Same');
pause

%Playing speech
sound(x,fs); %original speech sampled at 8000
pause;
sound(x(1:2:length(x)), fs/2);
pause
sound(yd,fs/2); %Speech decimated by 2 without polyphase decomposition 
pause;				
sound(yp,fs/2); %speech decimated by 2 using polyphase decomposition





